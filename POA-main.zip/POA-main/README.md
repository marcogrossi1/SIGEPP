# PIPA

## Plataforma Integrada de Projetos Acadêmicos

## INF - 2A

![image](https://github.com/user-attachments/assets/c9d2a0f5-6a56-498d-92fd-b93781aa3cd5)

## Diagrama de Caso de Uso
![image](https://github.com/user-attachments/assets/f3c10785-533f-43fb-94ad-ce93efc8171a)


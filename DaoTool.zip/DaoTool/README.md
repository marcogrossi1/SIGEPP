# Simple Dao Tool


### Utilitário para gerar uma Dao Simples para um Bean representando uma tabela do Banco de dados.

(Testado com MySQL)

Usado para ajudar no processo penoso de criação de DAOs.
Veja o exemplo de teste. Algumas anotações (além das JPA) estão definidas para judar no processo.

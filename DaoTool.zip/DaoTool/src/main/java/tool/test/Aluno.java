package tool.test;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import tool.annotation.GetBy;
import tool.annotation.ListBy;

public class Aluno {

	@Id  //gera as operaões de CRUD normais para o campo id
	@GeneratedValue //nao vai atualizar este campo
	private long id;
	
	
	@GetBy
	private String cpf;
	@ListBy
	private String nome;
	@ListBy
	private String curso;
	@ListBy
	private String campus;
	@GetBy
	private String email;
	@ListBy
	private String periodo;
	@GetBy
	private long   usuario_id;
	


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public String getCampus() {
		return campus;
	}

	public void setCampus(String campus) {
		this.campus = campus;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}


	
	public long getUsuario_id() {
		return usuario_id;
	}

	public void setUsuario_id(long usuario_id) {
		this.usuario_id = usuario_id;
	}
}


package tool.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import dao.NotFoundException;

public class EstagioDao {

    private final static String getsql = "SELECT * FROM estagio  WHERE id = ?";
    private final static String listsql = "SELECT * FROM estagio";
    private final static String listByEmpresaSql = "SELECT * FROM estagio WHERE empresa = ? ";
    private final static String insertsql = "INSERT INTO estagio (empresa, descricao, cargaHoraria, vagas, requisito, salario) VALUES( ?, ?, ?, ?, ?, ?) ";
    private final static String updatesql = "UPDATE estagio SET empresa = ?, descricao = ?, cargaHoraria = ?, vagas = ?, requisito = ?, salario = ? WHERE id = ? ";
    private final static String updateForEmpresaSql = "UPDATE estagio SET empresa = ?  WHERE id = ? ";
    private final static String updateForDescricaoSql = "UPDATE estagio SET descricao = ?  WHERE id = ? ";
    private final static String updateForCargaHorariaSql = "UPDATE estagio SET cargaHoraria = ?  WHERE id = ? ";
    private final static String updateForVagasSql = "UPDATE estagio SET vagas = ?  WHERE id = ? ";
    private final static String updateForRequisitoSql = "UPDATE estagio SET requisito = ?  WHERE id = ? ";
    private final static String updateForSalarioSql = "UPDATE estagio SET salario = ?  WHERE id = ? ";
    private final static String deletesql = "DELETE FROM estagio WHERE id = ?";

    private static void closeResource(Statement ps) {
        try{if (ps != null) ps.close();}catch (Exception e){ps = null;}
    }

    private static void closeResource(Statement ps, ResultSet rs) {
        try{if (rs != null) rs.close();}catch (Exception e){rs = null;}
        try{if (ps != null) ps.close();}catch (Exception e){ps = null;}
    }

    static Estagio set(ResultSet rs)
        throws SQLException
    {
        Estagio vo = new Estagio();
        vo.setId(rs.getLong("id"));
        vo.setEmpresa(rs.getString("empresa"));
        vo.setDescricao(rs.getString("descricao"));
        vo.setCargaHoraria(rs.getInt("cargaHoraria"));
        vo.setVagas(rs.getInt("vagas"));
        vo.setRequisito(rs.getString("requisito"));
        vo.setSalario(rs.getString("salario"));
        return vo;
    }

    public static Estagio get(Connection conn, long id)
        throws NotFoundException, SQLException
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(getsql);
            ps.setLong(1, id);
            rs = ps.executeQuery();
            if (!rs.next()) {throw new NotFoundException("Object not found [" + id + "]");}
            Estagio b = set(rs);
            return b;
        }
        catch (SQLException e){throw e;}
        finally{closeResource(ps,rs); ps = null;rs = null; }
    }

    public static ArrayList<Estagio> list(Connection conn)
        throws SQLException
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(listsql);
            rs = ps.executeQuery();
            if (!rs.next()) {return new ArrayList<Estagio>();}
            ArrayList<Estagio> list = new ArrayList<Estagio>();
            do
            { Estagio b = set(rs); list.add(b); }
            while (rs.next());
            return list;
        }
        catch (SQLException e){ throw e;}
        finally{closeResource(ps,rs); ps = null;rs = null; }
    }

    public static ArrayList<Estagio> listByEmpresa(Connection conn, String empresa)
        throws SQLException
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(listByEmpresaSql);
            ps.setString(1, empresa);
            rs = ps.executeQuery();
            if (!rs.next()) {return new ArrayList<Estagio>();}
            ArrayList<Estagio> list = new ArrayList<Estagio>();
            do
            { Estagio b = set(rs); list.add(b); }
            while (rs.next());
            return list;
        }
        catch (SQLException e){ throw e;}
        finally{closeResource(ps,rs); ps = null;rs = null; }
    }

    public static void insert(Connection conn, Estagio vo)
        throws SQLException
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(insertsql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, vo.getEmpresa());
            ps.setString(2, vo.getDescricao());
            ps.setInt(3, vo.getCargaHoraria());
            ps.setInt(4, vo.getVagas());
            ps.setString(5, vo.getRequisito());
            ps.setString(6, vo.getSalario());
            ps.executeUpdate();
            rs = ps.getGeneratedKeys();
            if (rs.next()) {
            long id = rs.getLong(1);
            vo.setId(id);
            }else { throw new SQLException("Nao foi possivel recuperar a CHAVE gerada na criacao do registro no banco de dados");} 
        }
        catch (SQLException e){try{conn.rollback();} catch (Exception e1){}; throw e;}
        finally{closeResource(ps,rs); ps = null;rs = null; }
    }

    public static void update(Connection conn, Estagio vo)
        throws NotFoundException, SQLException
    {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(updatesql);
            ps.setString(1, vo.getEmpresa());
            ps.setString(2, vo.getDescricao());
            ps.setInt(3, vo.getCargaHoraria());
            ps.setInt(4, vo.getVagas());
            ps.setString(5, vo.getRequisito());
            ps.setString(6, vo.getSalario());
            ps.setLong(7, vo.getId());
            int count = ps.executeUpdate();
            if (count == 0 ){ throw new NotFoundException("Object not found ["+ vo.getId()+"] ."); }
            //SEM COMMIT 
        }
        catch (SQLException e){try{conn.rollback();} catch (Exception e1){}; throw e;}
        finally{closeResource(ps); ps = null; }
    }

    public static void updateForEmpresa(Connection conn, long id, String empresa)
        throws NotFoundException, SQLException
    {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(updateForEmpresaSql);
            ps.setString(1, empresa);
            ps.setLong(2, id);
            int count = ps.executeUpdate();
            if (count == 0 ){ throw new NotFoundException("Object not found ["+ id + "] ."); }
            //SEM COMMIT 
        }
        catch (SQLException e){try{conn.rollback();} catch (Exception e1){}; throw e;}
        finally{closeResource(ps); ps = null; }
    }

    public static void updateForDescricao(Connection conn, long id, String descricao)
        throws NotFoundException, SQLException
    {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(updateForDescricaoSql);
            ps.setString(1, descricao);
            ps.setLong(2, id);
            int count = ps.executeUpdate();
            if (count == 0 ){ throw new NotFoundException("Object not found ["+ id + "] ."); }
            //SEM COMMIT 
        }
        catch (SQLException e){try{conn.rollback();} catch (Exception e1){}; throw e;}
        finally{closeResource(ps); ps = null; }
    }

    public static void updateForCargaHoraria(Connection conn, long id, int cargaHoraria)
        throws NotFoundException, SQLException
    {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(updateForCargaHorariaSql);
            ps.setInt(1, cargaHoraria);
            ps.setLong(2, id);
            int count = ps.executeUpdate();
            if (count == 0 ){ throw new NotFoundException("Object not found ["+ id + "] ."); }
            //SEM COMMIT 
        }
        catch (SQLException e){try{conn.rollback();} catch (Exception e1){}; throw e;}
        finally{closeResource(ps); ps = null; }
    }

    public static void updateForVagas(Connection conn, long id, int vagas)
        throws NotFoundException, SQLException
    {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(updateForVagasSql);
            ps.setInt(1, vagas);
            ps.setLong(2, id);
            int count = ps.executeUpdate();
            if (count == 0 ){ throw new NotFoundException("Object not found ["+ id + "] ."); }
            //SEM COMMIT 
        }
        catch (SQLException e){try{conn.rollback();} catch (Exception e1){}; throw e;}
        finally{closeResource(ps); ps = null; }
    }

    public static void updateForRequisito(Connection conn, long id, String requisito)
        throws NotFoundException, SQLException
    {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(updateForRequisitoSql);
            ps.setString(1, requisito);
            ps.setLong(2, id);
            int count = ps.executeUpdate();
            if (count == 0 ){ throw new NotFoundException("Object not found ["+ id + "] ."); }
            //SEM COMMIT 
        }
        catch (SQLException e){try{conn.rollback();} catch (Exception e1){}; throw e;}
        finally{closeResource(ps); ps = null; }
    }

    public static void updateForSalario(Connection conn, long id, String salario)
        throws NotFoundException, SQLException
    {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(updateForSalarioSql);
            ps.setString(1, salario);
            ps.setLong(2, id);
            int count = ps.executeUpdate();
            if (count == 0 ){ throw new NotFoundException("Object not found ["+ id + "] ."); }
            //SEM COMMIT 
        }
        catch (SQLException e){try{conn.rollback();} catch (Exception e1){}; throw e;}
        finally{closeResource(ps); ps = null; }
    }

    public static void delete(Connection conn, long id)
        throws NotFoundException, SQLException
    {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(deletesql);
            ps.setLong(1,id);
            int count = ps.executeUpdate();
            if (count == 0 ){throw new NotFoundException("Object not found ["+id+"] .");}
        }
        catch (SQLException e){try{conn.rollback();} catch (Exception e1){}; throw e;}
        finally{closeResource(ps); ps = null; }
    }

}
